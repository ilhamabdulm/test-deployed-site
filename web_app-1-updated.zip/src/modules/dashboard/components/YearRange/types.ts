export type YearRangeProps = {
  startYear: number;
  endYear: number;
  onSelect: CallableFunction;
};
