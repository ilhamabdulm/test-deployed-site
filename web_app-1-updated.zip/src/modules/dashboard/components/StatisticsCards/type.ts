import { StatisticsResponse } from '../../../../types/response';

export type StatisticsCardsProps = {
  statistics?: StatisticsResponse | null;
};
