import React from 'react';

export type ProtectedPageArgs = {
  children: React.ReactElement | null;
};
